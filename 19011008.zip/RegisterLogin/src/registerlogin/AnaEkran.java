/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registerlogin;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * 
 * 
 * 
 * 
 * @author kerim
 * 
 * 
 * 
 * 
 */
class SecilenAlistirma{
    private int sayi1max;
    private int sayi2max;
    private int sorusayisi;
    private String alıstırmaadi;

    public SecilenAlistirma(int sayi1max, int sayi2max, int sorusayisi, String alıstırmaadi) {
        this.sayi1max = sayi1max;
        this.sayi2max = sayi2max;
        this.sorusayisi = sorusayisi;
        this.alıstırmaadi = alıstırmaadi;
    }

    

    public int getSayi1max() {
        return sayi1max;
    }

    public void setSayi1max(int sayi1max) {
        this.sayi1max = sayi1max;
    }

    public int getSayi2max() {
        return sayi2max;
    }

    public void setSayi2max(int sayi2max) {
        this.sayi2max = sayi2max;
    }

    public int getSorusayisi() {
        return sorusayisi;
    }

    public void setSorusayisi(int sorusayisi) {
        this.sorusayisi = sorusayisi;
    }

    public String getAlıstırmaadi() {
        return alıstırmaadi;
    }

    public void setAlıstırmaadi(String alıstırmaadi) {
        this.alıstırmaadi = alıstırmaadi;
    }
    
}
class Alıstırma{
    private int sayi1max;
    private int sayi2max;
    private int sorusayisi;
    private String alıstırmaadi;

    public Alıstırma(String sayi1max, String sayi2max, String sorusayisi, String alıstırmaadi) {
        this.sayi1max = Integer.valueOf(sayi1max);
        this.sayi2max = Integer.valueOf(sayi2max);
        this.sorusayisi = Integer.valueOf(sorusayisi);
        this.alıstırmaadi = alıstırmaadi;
    }

    public String getAlıstırmaadi() {
        return alıstırmaadi;
    }

    public void setAlıstırmaadi(String alıstırmaadi) {
        this.alıstırmaadi = alıstırmaadi;
    }

    public int getSayi1max() {
        return sayi1max;
    }

    public void setSayi1max(int sayi1max) {
        this.sayi1max = sayi1max;
    }

    public int getSayi2max() {
        return sayi2max;
    }

    public void setSayi2max(int sayi2max) {
        this.sayi2max = sayi2max;
    }

    public int getSorusayisi() {
        return sorusayisi;
    }

    public void setSorusayisi(int sorusayisi) {
        this.sorusayisi = sorusayisi;
    }
    
    
}
class cevaplar implements Serializable{
    private String ogrenci_adi;
    private String dogru_sayisi;
    private String yanlis_sayisi;
    private String alıstırma_adi;
    private String alıstırma_suresi;
    private String skor;

    

   
    public cevaplar (String ogrenci_adi, String dogru_sayisi, String yanlis_sayisi, String alıstırma_adi, String alıstırma_suresi, String skor) {
        this.ogrenci_adi = ogrenci_adi;
        this.dogru_sayisi = dogru_sayisi;
        this.yanlis_sayisi = yanlis_sayisi;
        this.alıstırma_adi = alıstırma_adi;
        this.alıstırma_suresi = alıstırma_suresi;
        this.skor = skor;
    }
    public String getSkor() {
        return skor;
    }

    public void setSkor(String skor) {
        this.skor = skor;
    }

    public String getOgrenci_adi() {
        return ogrenci_adi;
    }

    public void setOgrenci_adi(String ogrenci_adi) {
        this.ogrenci_adi = ogrenci_adi;
    }

    public String getDogru_sayisi() {
        return dogru_sayisi;
    }

    public void setDogru_sayisi(String dogru_sayisi) {
        this.dogru_sayisi = dogru_sayisi;
    }

    public String getYanlis_sayisi() {
        return yanlis_sayisi;
    }

    public void setYanlis_sayisi(String yanlis_sayisi) {
        this.yanlis_sayisi = yanlis_sayisi;
    }

    public String getAlıstırma_adi() {
        return alıstırma_adi;
    }

    public void setAlıstırma_adi(String alıstırma_adi) {
        this.alıstırma_adi = alıstırma_adi;
    }

    public String getAlıstırma_suresi() {
        return alıstırma_suresi;
    }

    public void setAlıstırma_suresi(String alıstırma_suresi) {
        this.alıstırma_suresi = alıstırma_suresi;
    }
    
}
class User implements Serializable{
    private String kullanici_adi;
    private String parola;
    private String rol;

    public User(String kullanici_adi, String parola, String rol) {
        this.kullanici_adi = kullanici_adi;
        this.parola = parola;
        this.rol=rol;
    }

    @Override
    public String toString() {
        String bilgiler = "Kullanici adi : "+ kullanici_adi +
                           "\nParola : "+ parola +
                           "\n Rol : "+ rol;
        return bilgiler;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getKullanici_adi() {
        return kullanici_adi;
    }

    public void setKullanici_adi(String kullanici_adi) {
        this.kullanici_adi = kullanici_adi;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }
    
}





public class AnaEkran extends javax.swing.JFrame {
    private static ArrayList<User> aktif_list = new ArrayList<User>();

    public static ArrayList<User> getAktif_list() {
        return aktif_list;
    }

    public static void setAktif_list(ArrayList<User> aktif_list) {
        AnaEkran.aktif_list = aktif_list;
    }
    
    private static ArrayList<User> user_list = new ArrayList<User>();

    public static ArrayList<User> getUser_list() {
        return user_list;
    }

    public static void setUser_list(ArrayList<User> user_list) {
        AnaEkran.user_list = user_list;
    }
    private static ArrayList<Alıstırma> alıstırma_list = new ArrayList<Alıstırma>();

    public static ArrayList<Alıstırma> getAlıstırma_list() {
        return alıstırma_list;
    }

    public static void setAlıstırma_list(ArrayList<Alıstırma> alıstırma_list) {
        AnaEkran.alıstırma_list = alıstırma_list;
    }
    private static ArrayList<SecilenAlistirma> secalıstırma_list = new ArrayList<SecilenAlistirma>();

    public static ArrayList<SecilenAlistirma> getSecalıstırma_list() {
        return secalıstırma_list;
    }

    public static void setSecalıstırma_list(ArrayList<SecilenAlistirma> secalıstırma_list) {
        AnaEkran.secalıstırma_list = secalıstırma_list;
    }
    private static ArrayList<cevaplar> cevaplar_list = new ArrayList<cevaplar>();

    public static ArrayList<cevaplar> getCevaplar_list() {
        return cevaplar_list;
    }

    public static void setCevaplar_list(ArrayList<cevaplar> cevaplar_list) {
        AnaEkran.cevaplar_list = cevaplar_list;
    }
    

    

    /**
     * Creates new form AnaEkran
     */
    public AnaEkran() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        registerloginpanel = new javax.swing.JPanel();
        register = new javax.swing.JButton();
        login = new javax.swing.JButton();
        loginpanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        kullanici_adi_alani = new javax.swing.JTextField();
        parola_alani = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        registerloginpanel.setBackground(new java.awt.Color(204, 0, 102));

        register.setText("Register");
        register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerActionPerformed(evt);
            }
        });

        login.setText("Login");
        login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout registerloginpanelLayout = new javax.swing.GroupLayout(registerloginpanel);
        registerloginpanel.setLayout(registerloginpanelLayout);
        registerloginpanelLayout.setHorizontalGroup(
            registerloginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(registerloginpanelLayout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(register)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 224, Short.MAX_VALUE)
                .addComponent(login)
                .addGap(163, 163, 163))
        );
        registerloginpanelLayout.setVerticalGroup(
            registerloginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(registerloginpanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(registerloginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(register)
                    .addComponent(login))
                .addContainerGap(45, Short.MAX_VALUE))
        );

        loginpanel.setBackground(new java.awt.Color(51, 51, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Kullanıcı Adı :");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("İsim : ");

        kullanici_adi_alani.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                kullanici_adi_alaniActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout loginpanelLayout = new javax.swing.GroupLayout(loginpanel);
        loginpanel.setLayout(loginpanelLayout);
        loginpanelLayout.setHorizontalGroup(
            loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginpanelLayout.createSequentialGroup()
                .addGap(101, 101, 101)
                .addGroup(loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addGap(36, 36, 36)
                .addGroup(loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(kullanici_adi_alani, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addComponent(parola_alani))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        loginpanelLayout.setVerticalGroup(
            loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginpanelLayout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addGroup(loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(kullanici_adi_alani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(loginpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(parola_alani, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(96, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(registerloginpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(loginpanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(loginpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(registerloginpanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void kullanici_adi_alaniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_kullanici_adi_alaniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_kullanici_adi_alaniActionPerformed

    private void registerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerActionPerformed
        RegisterEkrani registerekrani = new RegisterEkrani();
        registerekrani.setVisible(true);
    }//GEN-LAST:event_registerActionPerformed

    private void loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginActionPerformed
        String kullanici_adi = kullanici_adi_alani.getText();
        String parola = new String(parola_alani.getPassword()); 
        
        if(user_list.size()== 0){
            JOptionPane.showMessageDialog(this, "Hiçbir kullanici bulunmamaktadir...");
        }else{
            for(User user : user_list){
                if(user.getKullanici_adi().equals(kullanici_adi) && user.getParola().equals(parola)){
                    if(user.getRol().equals("Ogretmen")){
                        JOptionPane.showMessageDialog(this, "Hoşgeldiniz Hocam " + kullanici_adi );
                        aktif_list.add(0, user);
                        AdminEkran adminekrani = new AdminEkran();
                        adminekrani.setVisible(true);
                    }
                    
                    else{
                        JOptionPane.showMessageDialog(this, "Hoşgeldiniz ogrenci " + kullanici_adi );
                        aktif_list.add(0, user);
                        OgrenciEkran ogrenciekrani = new OgrenciEkran();
                        ogrenciekrani.setVisible(true);
                    }
                    return;
                }                    
               
            }
            JOptionPane.showMessageDialog(this, "Böyle bir kullanici bulunmamaktadir....");
        }
                
                
                
                
    }//GEN-LAST:event_loginActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        //Kullanıcı id şifre ekleme****************************************************************************
        user_list.add(new User("33kerim33","3353","Ogretmen"));
        user_list.add(new User("ogren","3353","ogrenci"));
        
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream("user.bin"))){
            ArrayList<User> okunan_list = (ArrayList<User>)in.readObject();
            for(User user : okunan_list){
                user_list.add(user);
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println("Dosya Bulunamadi....");
        } catch (IOException ex) {
            System.out.println("Dosya açılırken IOException oluştu....");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AnaEkran.class.getName()).log(Level.SEVERE, null, ex);
        }
        ////////////////////////
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream("cevaplar.bin"))){
            ArrayList<cevaplar> okunan_list = (ArrayList<cevaplar>)in.readObject();
            for(cevaplar cevap : okunan_list){
                cevaplar_list.add(cevap);
            }
            
        } catch (FileNotFoundException ex) {
            System.out.println("Cevaplar Dosya Bulunamadi....");
        } catch (IOException ex) {
            System.out.println("Cevaplar Dosya açılırken IOException oluştu....");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AnaEkran.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        alıstırma_list.add(new Alıstırma("12","15","5","alsıtırma1"));
        alıstırma_list.add(new Alıstırma("4","8","3","alsıtırma2"));
        alıstırma_list.add(new Alıstırma("7","4","9","alsıtırma3"));
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AnaEkran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AnaEkran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AnaEkran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AnaEkran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AnaEkran().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JTextField kullanici_adi_alani;
    private javax.swing.JButton login;
    private javax.swing.JPanel loginpanel;
    private javax.swing.JPasswordField parola_alani;
    private javax.swing.JButton register;
    private javax.swing.JPanel registerloginpanel;
    // End of variables declaration//GEN-END:variables
}
