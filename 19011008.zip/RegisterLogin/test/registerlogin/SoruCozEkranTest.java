/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registerlogin;

import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SoruCozEkranTest {
    private SoruCozEkran soruCozEkran;

    @Before
    public void setUp() {
        soruCozEkran = new SoruCozEkran();
    }

    @Test
    public void testSetMaxSayi2() {
    int maxSayi2 = 200;
    soruCozEkran.setMaxSayi2(maxSayi2);
    Assert.assertEquals(maxSayi2, soruCozEkran.getMaxSayi2());
}


    @Test
    public void testSetMaxSayi1() {
        int maxSayi1 = 100;
        soruCozEkran.setMaxSayi1(maxSayi1);
        Assert.assertEquals(maxSayi1, soruCozEkran.getMaxSayi1());
}

    @Test
public void testToplamSayi() {
    int sayi1 = 5;
    int sayi2 = 10;
    int expectedToplam = 15;
    int actualToplam = soruCozEkran.toplamSayi(sayi1, sayi2);
    Assert.assertEquals(expectedToplam, actualToplam);
}
@Test
public void testGetKarsilamaMesaji() {
    String isim = "Ahmet";
    String expectedMesaj = "Merhaba, Ahmet!";
    String actualMesaj = soruCozEkran.getKarsilamaMesaji(isim);
    Assert.assertEquals(expectedMesaj, actualMesaj);
}


    // Diğer test metodlarını buraya ekleyebilirsiniz

}
